﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;//得有这个头文件才能支持串口

namespace pureTextShow
{
    public partial class Form1 : Form
    {
        private SerialPort serialPort;
        public Form1()
        {
            InitializeComponent();
            serialPort = new SerialPort();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            System.Windows.Forms.Control.CheckForIllegalCrossThreadCalls = false;//禁用了所有的控件合法性检查

            baudrate_comboBox2.Items.Add(115200);
            baudrate_comboBox2.Text = baudrate_comboBox2.Items[0].ToString();//波特率默认值

            databits_comboBox3.Items.Add(8);
            databits_comboBox3.Text = databits_comboBox3.Items[0].ToString();//数据位默认值肯定是数组第一个元素了

            stopbits_comboBox4.Items.Add(1);
            stopbits_comboBox4.Text = stopbits_comboBox4.Items[0].ToString();

            string[] ArrComPortsName = SerialPort.GetPortNames();//获取当前串口个数名称
            if (ArrComPortsName.Length != 0)
            {
                Array.Sort(ArrComPortsName);
            }
            for (int portNUM_cnt = 0; portNUM_cnt < ArrComPortsName.Length; portNUM_cnt++)
            {
                portnum_comboBox1.Items.Add(ArrComPortsName[portNUM_cnt]);
            }
            portnum_comboBox1.Text = ArrComPortsName[0];//端口号默认值
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                do
                {
                    //serialPort.ReadBufferSize();
                    int count = serialPort.BytesToRead;  // 串口的接收缓冲区，
                    if (count <= 0)   //count <= 0 ：表示没有接收到指令
                        break;
                    Byte[] dataBuff = new Byte[count];//一帧数据长8个字节，后两位是CRC校验值

                    serialPort.Read(dataBuff, 0, count);  //串口读取接收缓存区的数据

                    angle_textBox1.Text = BitConverter.ToSingle(dataBuff, 2).ToString();//对于dataBuff数组从第二个元素开始检索，从第二个元素开始是有效数据。

                } while (serialPort.BytesToRead > 0);

            }
            catch (Exception ex)
            {
                MessageBox.Show("error:接收返回信息异常：" + ex.Message);
            }      
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort.PortName = portnum_comboBox1.Text;
                serialPort.BaudRate = Convert.ToInt32(baudrate_comboBox2.Text);  //转换为10进制
                serialPort.DataBits = Convert.ToInt16(databits_comboBox3.Text);
                serialPort.StopBits = (StopBits)Enum.Parse(typeof(StopBits), stopbits_comboBox4.Text);
                serialPort.Open();

                serialPort.ReceivedBytesThreshold = 8; //获取或设置 System.IO.Ports.SerialPort.DataReceived 事件发生前内部输入缓冲区中的字节数。
                serialPort.DataReceived += new SerialDataReceivedEventHandler(serialPort1_DataReceived); //串口接收指令事件

                button1.Enabled = false;  //打开按钮不可用         

            }
            catch
            {
                MessageBox.Show("串口设置错误");
            }
        }
    }
}
